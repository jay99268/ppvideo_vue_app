<!-- src/App.vue -->
<script setup>
import { RouterView } from 'vue-router'
import TheHeader from '@/components/TheHeader.vue'
import TheFooter from '@/components/TheFooter.vue'
import MobileNav from '@/components/MobileNav.vue'
</script>

<template>
  <div class="min-h-screen flex flex-col bg-gray-900 text-gray-300">
    <TheHeader />
    <!-- 为移动端底部导航栏留出空间 -->
    <main class="flex-grow container mx-auto px-4 py-8 pb-24 md:pb-8">
      <RouterView />
    </main>
    <TheFooter />
    <MobileNav />
  </div>
</template>
