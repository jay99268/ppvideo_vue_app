// src/stores/auth.js
import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import api from '@/api'
import router from '@/router'
import { useProfileStore } from './profile' // 引入 profile store

export const useAuthStore = defineStore('auth', () => {
  const user = ref(JSON.parse(localStorage.getItem('user')) || null)
  const token = ref(localStorage.getItem('token') || null)

  const isAuthenticated = computed(() => !!token.value && !!user.value)

  async function login(credentials) {
    try {
      const response = await api.post('/auth/login', credentials)
      const data = response.data

      token.value = data.token
      user.value = {
        username: data.username,
        email: data.email,
        vipStatus: data.vipStatus,
        vipExpiresAt: data.vipExpiresAt
      }

      localStorage.setItem('token', token.value)
      localStorage.setItem('user', JSON.stringify(user.value))

      api.defaults.headers.common['Authorization'] = `Bearer ${token.value}`

      // 登录成功后，获取收藏列表
      const profileStore = useProfileStore()
      await profileStore.fetchFavoriteIds()

      const redirectPath = router.currentRoute.value.query.redirect || '/'
      router.push(redirectPath)
      return { success: true }
    } catch (error) {
      console.error('登录失败:', error)
      await logout({ redirect: false })
      return { success: false, message: error.response?.data || '登录失败，请重试' }
    }
  }

  async function logout({ redirect = true } = {}) {
    user.value = null
    token.value = null
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    delete api.defaults.headers.common['Authorization']

    // 登出时，清空收藏列表
    const profileStore = useProfileStore()
    profileStore.clearFavorites()

    if (redirect) {
      await router.push({ name: 'home' })
    }
  }

  function tryAutoLogin() {
    const storedToken = localStorage.getItem('token')
    if (storedToken && user.value) {
      token.value = storedToken
      api.defaults.headers.common['Authorization'] = `Bearer ${storedToken}`
      // 应用加载时，如果已登录，也获取收藏列表
      const profileStore = useProfileStore()
      profileStore.fetchFavoriteIds()
    }
  }

  async function sendVerificationCode(email) {
    try {
      const response = await api.post('/auth/send-verification-code', { email })
      return { success: true, message: response.data.message }
    } catch (error) {
      return { success: false, message: error.response?.data || '验证码发送失败' }
    }
  }

  async function register(details) {
    try {
      const response = await api.post('/auth/register', details)
      return { success: true, message: response.data.message }
    } catch (error) {
      return { success: false, message: error.response?.data || '注册失败' }
    }
  }

  return { user, token, isAuthenticated, login, logout, tryAutoLogin, sendVerificationCode, register }
})
