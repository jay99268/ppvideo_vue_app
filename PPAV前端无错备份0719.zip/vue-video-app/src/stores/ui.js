// src/stores/ui.js
import { ref } from 'vue'
import { defineStore } from 'pinia'

export const useUiStore = defineStore('ui', () => {
  const isVipModalOpen = ref(false)

  function openVipModal() {
    isVipModalOpen.value = true
  }

  function closeVipModal() {
    isVipModalOpen.value = false
  }

  return { isVipModalOpen, openVipModal, closeVipModal }
})
