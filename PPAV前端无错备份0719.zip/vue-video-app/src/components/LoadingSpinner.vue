<!-- src/components/LoadingSpinner.vue -->
<template>
  <div class="flex justify-center items-center py-10">
    <div
      class="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-400"
    ></div>
  </div>
</template>
