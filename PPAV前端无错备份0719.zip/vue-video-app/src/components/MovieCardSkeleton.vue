<!-- src/components/MovieCardSkeleton.vue -->
<script setup>
</script>
<template>
  <div class="relative overflow-hidden rounded-lg bg-gray-700 aspect-[3/4]">
    <div class="absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-gray-700 via-gray-600 to-gray-700"></div>
  </div>
</template>
