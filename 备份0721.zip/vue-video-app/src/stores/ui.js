// src/stores/ui.js
import { ref } from 'vue'
import { defineStore } from 'pinia'

export const useUiStore = defineStore('ui', () => {
  const isLightboxOpen = ref(false)
  const lightboxImages = ref([])
  const currentLightboxIndex = ref(0)

  function openLightbox(images, startIndex = 0) {
    lightboxImages.value = images
    currentLightboxIndex.value = startIndex
    isLightboxOpen.value = true
  }

  function closeLightbox() {
    isLightboxOpen.value = false
  }

  function nextImage() {
    if (lightboxImages.value.length > 0) {
      currentLightboxIndex.value = (currentLightboxIndex.value + 1) % lightboxImages.value.length
    }
  }

  function prevImage() {
    if (lightboxImages.value.length > 0) {
      currentLightboxIndex.value = (currentLightboxIndex.value - 1 + lightboxImages.value.length) % lightboxImages.value.length
    }
  }

  return { isLightboxOpen, lightboxImages, currentLightboxIndex, openLightbox, closeLightbox, nextImage, prevImage }
})
