// src/stores/gossip.js
import { ref, reactive } from 'vue'
import { defineStore } from 'pinia'
import api from '@/api'

const PAGE_SIZE = 10;

export const useGossipStore = defineStore('gossip', () => {
  const posts = ref([])
  const isLoading = ref(false)
  const error = ref(null)
  const page = ref(1)
  const hasMore = ref(true)
  const isLoadingMore = ref(false)

  async function fetchInitialPosts() {
    isLoading.value = true
    error.value = null
    page.value = 1
    try {
      const response = await api.get('/gossip/posts', { params: { pageIndex: 1, pageSize: PAGE_SIZE } })
      posts.value = response.data.items
      hasMore.value = response.data.items.length === PAGE_SIZE
    } catch (err) {
      console.error('获取吃瓜中心数据失败:', err)
      error.value = err.response?.data || '无法加载内容，请先开通VIP。'
    } finally {
      isLoading.value = false
    }
  }

  async function loadMorePosts() {
    if (!hasMore.value || isLoadingMore.value) return

    isLoadingMore.value = true
    page.value++
    try {
      const response = await api.get('/gossip/posts', { params: { pageIndex: page.value, pageSize: PAGE_SIZE } })
      const newItems = response.data.items
      posts.value.push(...newItems)
      if (newItems.length < PAGE_SIZE) {
        hasMore.value = false
      }
    } catch (err) {
      console.error('加载更多吃瓜中心数据失败:', err)
      page.value--
    } finally {
      isLoadingMore.value = false
    }
  }

  function reset() {
    posts.value = []
    isLoading.value = false
    error.value = null
    page.value = 1
    hasMore.value = true
    isLoadingMore.value = false
  }

  return { posts, isLoading, error, hasMore, isLoadingMore, fetchInitialPosts, loadMorePosts, reset }
})
