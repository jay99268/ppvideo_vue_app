<!-- src/views/GossipView.vue -->
<script setup>
import { onMounted, onUnmounted, ref } from 'vue'
import { useGossipStore } from '@/stores/gossip'
import { storeToRefs } from 'pinia'
import GossipCard from '@/components/GossipCard.vue'
import LoadingSpinner from '@/components/LoadingSpinner.vue'
import { AlertTriangle } from 'lucide-vue-next'

const gossipStore = useGossipStore()
const { posts, isLoading, error, hasMore, isLoadingMore } = storeToRefs(gossipStore)

const sentinel = ref(null)
let observer = null

onMounted(() => {
  gossipStore.fetchInitialPosts()

  observer = new IntersectionObserver(([entry]) => {
    if (entry && entry.isIntersecting) {
      gossipStore.loadMorePosts()
    }
  }, { threshold: 0.5 })

  if (sentinel.value) {
    observer.observe(sentinel.value)
  }
})

onUnmounted(() => {
  if (observer) {
    observer.disconnect()
  }
  gossipStore.reset()
})
</script>

<template>
  <div class="max-w-2xl mx-auto">
    <h1 class="text-3xl font-bold text-white mb-8 text-center">吃瓜中心</h1>

    <div v-if="isLoading">
      <LoadingSpinner />
    </div>
    <div v-else-if="error" class="text-center py-20 text-red-400">
      <AlertTriangle class="mx-auto w-12 h-12 mb-4" />
      <p class="text-xl font-semibold">{{ error }}</p>
    </div>
    <div v-else class="space-y-6">
      <GossipCard v-for="post in posts" :key="post.id" :post="post" />

      <!-- Sentinel for infinite scroll -->
      <div ref="sentinel" class="h-10">
        <div v-if="isLoadingMore">
          <LoadingSpinner />
        </div>
        <p v-if="!hasMore && posts.length > 0" class="text-center text-gray-500 text-sm">
          — 没有更多了 —
        </p>
      </div>
    </div>
  </div>
</template>
