<!-- src/components/TheFooter.vue -->
<script setup>
// An empty script tag is added to ensure it's treated as a valid SFC.
</script>
<template>
  <footer class="bg-gray-800 border-t border-gray-700 mt-auto">
    <div class="container mx-auto py-6 px-4 text-center text-gray-400 text-sm">
      <p>&copy; {{ new Date().getFullYear() }} 流光影院. All Rights Reserved.</p>
      <p class="mt-2">商务联系:ccccczhi@gmail.com。</p>
    </div>
  </footer>
</template>
